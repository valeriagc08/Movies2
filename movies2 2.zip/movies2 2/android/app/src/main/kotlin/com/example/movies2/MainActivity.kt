package com.example.movies2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
