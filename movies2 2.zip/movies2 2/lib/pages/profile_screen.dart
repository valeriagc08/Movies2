import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:movies2/main.dart';
import 'package:provider/provider.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  

  @override
  Widget build(BuildContext context) {
    double currentWidth=MediaQuery.of(context).size.width;


    return Scaffold(
      backgroundColor: currentWidth < 600? Colors.black: Color.fromARGB(214, 3, 3, 3),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(
              height: 50,
            ),
            Icon(
              Icons.lock,
              color: Colors.white,
              size: currentWidth < 600 ? 60.0 : 120.0,
            ),   
            //Welcom Back messafe
            Text(
              'Welcome Back',
              style: TextStyle(
                  color: Colors.white, 
                  fontSize: currentWidth < 600 ? 20.0 : 50.0, 
                  fontWeight: FontWeight.bold
                ),
            ),
            const SizedBox(height: 15,),

            GestureDetector(
              onTap: (){
                context.push('/profile/signed'); 
                Provider.of<AppSettings>(context, listen: false).toggleDetailsEnabled(true);
              },
              child: Text('Sign In',
              style: 
                TextStyle(
                fontWeight:FontWeight.bold,
                fontSize:currentWidth < 600 ? 15.0 : 30.0,
                color: Colors.white,
                ),
                ),
            )
          ],
        ),
      ),
    );
  }
}


