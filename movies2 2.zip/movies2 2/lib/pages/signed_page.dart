import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:movies2/main.dart';
import 'package:provider/provider.dart';
class SignedPage extends StatefulWidget {
  const SignedPage({super.key});

  @override
  State<SignedPage> createState() => _SignedPageState();
}

class _SignedPageState extends State<SignedPage> {
  
  @override
  Widget build(BuildContext context) {
    double currentWidth=MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor:  currentWidth < 600 ? Colors.black:Color.fromARGB(214, 3, 3, 3),
      body: Center(child: GestureDetector(
              onTap: (){
                context.go('/profile'); 
                Provider.of<AppSettings>(context, listen: false).toggleDetailsEnabled(false);
              },
            child: Text(
              'Sign Out', 
              style: TextStyle(
                color: Colors.white, 
                fontWeight:FontWeight.bold,
                fontSize: currentWidth < 600 ? 15.0 : 30.0),)
          ),
      
      ),
    );
  }

}